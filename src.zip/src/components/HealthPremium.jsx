import React, { useEffect, useRef, useState } from "react";
import "../css/Premium.css";
import { Card, Form } from "react-bootstrap";
import Button from "react-bootstrap/Button";
import OverlayTrigger from "react-bootstrap/OverlayTrigger";
import Popover from "react-bootstrap/Popover";
import { Modal, DropdownButton, ButtonGroup, Dropdown } from "react-bootstrap";
import axios from "axios";
import { Row, Col } from "react-bootstrap";
import HealthPremium2 from "./HealthPremium2";
import HealthPremium21 from "./HealthPremium21";

import { useRecoilState } from "recoil"; /////////////////
import { apiResponseHealthPremiumAtom } from "./recoilAtom"; /////////////////

const HealthPremium = () => {
  const [showSumAssured, setShowSumAssured] = React.useState(false);
  const [showCover, setShowCover] = React.useState(false);
  const [responseDataPremium, setResponseDataPremium] = React.useState([]);
  //recoil test
  const [apiResponseData, setApiResponseData] = useRecoilState(
    apiResponseHealthPremiumAtom
  );

  //recoil

  useEffect(() => {

  const apiUrls=[
    "http://localhost:5000/reliancehealth",
    "http://localhost:5000/godigithealth",
    "http://localhost:5000/bajajhealth",
    "http://localhost:5000/royalsundaramhealth",
    "http://localhost:5000/nationalinsurancehealth"
  ];
  const inputdata = localStorage.getItem("health_age_details");

    const data = {
     input_data:
     [
     {"relation": "Self", "Age": 43, Gender:"Male"},
     {"relation": "Spouse", "Age": 43, Gender:"Female"},
     {"relation": "Son", "Age": 22, Gender:"Male"},
     {"relation": "Daughter", "Age": 22, Gender:"Female"},
     {"relation": "Daughter", "Age": 21, Gender:"Female"}
    ],
    contact_form:{fullName:"dinto joy",age:27,pincode:683576,mobileNumber:9072072009,gender:"male"},
    policy_type:"health",
    room_limit:"all",
    si_range:500000,
    tenture:1
  }
  const authKey = localStorage.getItem('Auth-key');
  const headers = {
    'Content-Type': 'application/json',
    'Authorization': authKey,
  };
    const responses = [];
    const postRequests = apiUrls.map((endpoint) =>
      axios.post(endpoint, data,  { headers }).then((response) => {
        responses.push(response.data.data);
        console.log(responses);
        setApiResponseData([...responses]);
       
      })
    );

    Promise.all(postRequests)
      .then(() => {})
      .catch((error) => {
        console.error(error);
      });
  }, []);





  const popoverRef = useRef(null);
  const handleOptionChange = (event) => {
    if (event.target.value === "1L to 3L") {
      localStorage.setItem("Sum Assured", 1);
    } else if (event.target.value === "4L to 5L") {
      localStorage.setItem("Sum Assured", 2);
    } else if (event.target.value === "6L to 9L") {
      localStorage.setItem("Sum Assured", 3);
    } else if (event.target.value === "10L to 14L") {
      localStorage.setItem("Sum Assured", 4);
    } else if (event.target.value === "15L to 24L") {
      localStorage.setItem("Sum Assured", 5);
    } else if (event.target.value === "25L to 99L") {
      localStorage.setItem("Sum Assured", 6);
    } else if (event.target.value === "1Cr+") {
      localStorage.setItem("Sum Assured", 7);
    }
    setShowSumAssured(false);
  };

  const dropDownSumAssured = (
    <div>
      {showSumAssured && (
        <div>
          <Form.Check
            type="radio"
            name="Sum_Assured"
            id="1L to 3L"
            value="1L to 3L"
            label="1L to 3L"
            onChange={handleOptionChange}
          />
          <Form.Check
            type="radio"
            name="Sum_Assured"
            id="4L to 5L"
            value="4L to 5L"
            label="4L to 5L"
            onChange={handleOptionChange}
          />
          <Form.Check
            type="radio"
            name="Sum_Assured"
            id="6L to 9L"
            value="6L to 9L"
            label="6L to 9L"
            onChange={handleOptionChange}
          />
          <Form.Check
            type="radio"
            name="Sum_Assured"
            id="10L to 14L"
            value="10L to 14L"
            label="10L to 14L"
            onChange={handleOptionChange}
          />
          <Form.Check
            type="radio"
            name="Sum_Assured"
            id="15L to 24L"
            value="15L to 24L"
            label="15L to 24L"
            onChange={handleOptionChange}
          />
          <Form.Check
            type="radio"
            name="Sum_Assured"
            id="25L to 99L"
            value="25L to 99L"
            label="25L to 99L"
            onChange={handleOptionChange}
          />
          <Form.Check
            type="radio"
            name="Sum_Assured"
            id="1Cr+"
            value="1Cr+"
            label="1Cr+"
            onChange={handleOptionChange}
          />
        </div>
      )}
    </div>
  );
  return (
    <div className="container">
      <div className="row">
        <div className="col-md-5 mt-5">
          <h6>View Member Details</h6>
        </div>
      </div>
      <div className="row">
        <div className="col-md-12 mt-2">
          <Card
            className="w-100"
            style={{ backgroundColor: "#ECEFF1", height: "125px" }}
          >
            <Card.Body>
              <h6 style={{ paddingLeft: "15px" }}>
                <span style={{ marginRight: "30px" }}>Sum Assured:</span>
                <span
                  className="float-right"
                  style={{ paddingTop: "10px", paddingLeft: "0px" }}
                >
                  <DropdownButton
                    as={ButtonGroup}
                    drop="down"
                    className="car-premium-dropdownbtn"
                    onClick={() => setShowSumAssured(true)}
                  >
                    <Dropdown.Item>{dropDownSumAssured}</Dropdown.Item>
                  </DropdownButton>
                  {}
                </span>
              </h6>
            </Card.Body>
          </Card>
        </div>
        <HealthPremium2 />
        </div>
    </div>
  );
};
export default HealthPremium;
