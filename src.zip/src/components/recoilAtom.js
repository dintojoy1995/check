import { atom } from 'recoil';

export const apiResponseHealthPremiumAtom = atom({
  key: 'apiResponseHealthPremium',
  default: [],
});